const Admin=require("../models/Admin");
const complaint=require("../models/Complaint");

const bcrypt=require("bcrypt");
const jwt=require("jsonwebtoken");


const adminLogin=async (req,res)=>{
    try{
        const {email,password}=req.body;
        const admin=await Admin.findOne({email});
        if(!admin){
            return res.status(404).json({
                success:false,
                message:'Admin not found',
            });
        }
        const isMatch=await bcrypt.compare(password,admin.password); 
        //bcrypt.compare() checks the password entered during login.against the hashed password already stored in the database.and returns true or false.
        if(!isMatch){
            return res.status(401).json({
                success:false,
                message:"Invalid email or Password",
            })
        }
        const token=jwt.sign(
            {
                id:admin._id,
                email:admin.email,
                role:admin.role,
            },
            process.env.JWT_SECRET,
            {
                expiresIn:"1d",
            }
        );
       res.cookie("token",token,{
        httpOnly:true,
        maxAge:24*60*60*1000,
       });
       res.status(200).json({
        success:true,
        message:"Admin Login Successfull",
        admin,
       })
    }
    catch(error){
        res.status(500).json({
        success:false,
        message:error.message,
        });
    }};

/*adminLogin verifies the admin's email and password, creates a JWT token, stores it in a cookie, and allows the admin to access protected features.*/

const getAllComplaint=async (req,res)=>{
    try{
        const complaints=await Complaint.find().populate("student","name email");
        /*1. Complaint.find() => Gets all complaints from the Complaint collection.
       2.populate("student", "name email")=> Each complaint has a student field that usually stores the student's MongoDB _id.
       populate() takes that student ID and finds the corresponding student in the Student/User collection.
      Then: "student", "name email"  => means:Find the student using the student field containing the user's ID and give me only their name and email.
      so basically populate()=> Mongoose method replaces a referenced ID with the actual related document/data.*/
        res.status(200).json({
            success:true,
            complaints,//complaints = all the complaint data retrieved from MongoDB. mean=>Send these complaints to the frontend."
        })
    }catch(error){
        res.status(500).json({
            success:false,
            message:error.message,
        })
    }
};
//getAllComplaint fetches all complaints from the database and includes the related student's name and email using populate().

const updateComplaintStatus=async(req,res)=>{
    try{
        const {status}=req.body;
        const complaint =await Complaint.findById(req.params.id);// params = parameters from the URL. MongoDB searches for the complaint having that _id.
        if(!complaint){
            return res.status(404).json({
                success:false,
                message:"Complaint not found",
            });
        }
        complaint.status=status;;
        await complaint.save();
        res.status(200).json({
            success:true, 
              message:"Complaint status Updated Successfully",
            complaint,
        });
    }
    catch(error){
        res.status(500).json({
            success:false,
            message:error.message,
        })
    }
}
//updateComplaintStatus finds a complaint by its ID, updates its status, saves it in the database, and sends the updated complaint status back.

const getComplaintStatus=async (req,res)=>{
    try{
        const total=await Complaint.countDocuments();
        const pending=await Complaint.countDocuments({
            status:"Pending",
        });
        const inProgress=await Complaint.countDocuments({
            status:"In Progress",
        });
        const resolved=await Complaint.countDocuments({
            status:"Resolved",
        });
        res.status(200).json({
            success:true,
            stats:{
               total,
               pending,
               inProgress,
               resolved,
            }
        })
    }catch(error){
        res.status(500).json({
            success:false,
            message:error.message,
        });
    }
};
//getComplaintStatus counts complaints based on their status and sends the statistics to the frontend, mainly for displaying complaint statistics on an admin dashboard.

const adminLogout=async(req,res)=>{
    try{
        res.clearCookie("token");
        res.status(200).json({
            succes:true,
            message:"Admin Logout Successfully",
        });
    }catch(error){
        res.status(500).json({
            success:false,
            message:error.message,
        })
    }
}
//adminLogout removes the admin's JWT cookie, so the admin is logged out, and then sends a success response to the frontend.

module.exports={
    adminLogin,
    getAllComplaint,
    updateComplaintStatus,
    getComplaintStatus,
    adminLogout
}