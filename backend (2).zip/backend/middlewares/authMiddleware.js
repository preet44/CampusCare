const jwt=require("jsonwebtoken");
const AppError=require("../utils/AppError");

const authMiddleware=async (req,res)=>{
    try{
        const token=req.cookies.token;
        if(!token){
          throw new AppError(
            "Authentication required. Please Login.",
            401
          );
        }
        const decoded=jwt.verify(token,process.env.JWT_SECRET);
        req.user=decoded;
        //jwt.verify(token, secret) verifies that the JWT is authentic, hasn't been tampered with, and hasn't expired. If valid, it returns the decoded payload.
        // req.user = decoded stores the decoded user information in the request object so that the next middleware or controller can identify the authenticated user without querying the token again.
        next();
    }
    catch(error){
       if(error.name==="JsonWebTokenError"){
        return next(
            new AppError(
                "Invalid Authentication Token.Please Login again."
                401
            )
        )
       }

    }
}
module.exports=authMiddleware;