const mongoose=require("mongoose");

const complaintSchema=new mongoose.Schema(
    {
        title:{
            type:String,
            required:true,
              trim:true,
        },
        description:{
            type:String,
            required:true,
        },
        category:{
            type:String,
            required:true,
            enum:["Academic","hostel","Technical","Canteen","Library","furniture","other"]
        },
        status:{
            type:String,
            enum:[
                "Pending",
                "In Progress",
                "Resolved",
            ],
            default:"Pending",
        },
        student:{
            type:mongoose.Schema.Types.ObjectId,
            ref:"User",
            required:true
        },
    },
    {
        timestamps:true
    }
);
const Complaint=mongoose.model("Complaint",complaintSchema);
module.exports=Complaint;

