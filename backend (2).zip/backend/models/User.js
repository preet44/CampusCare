const mongoose=require("mongoose");

const userSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true,
        trim:true,
    },
    email:{
        type:String,
        required:true,
        trim:true,
        unique:true,

    },
    password:{
        type:String,
        required:true,
        minlength:6,
    },
},{
        timestamps:true,//timestamps: true automatically adds createdAt and updatedAt fields to every document and updates updatedAt whenever the document is modified.
    },
);
const User=mongoose.model("User",userSchema);
module.exports=User;