const express=require("express");
const router=express.Router();

const {adminLogin,getAllComplaint, updateComplaintStatus, getComplaintStatus, adminLogout}=
require("../controllers/adminController");
const {adminLoginValidation}=require("../validation/adminValidation");
const {adminMiddleware}=require("../middlewares/adminMiddleware");

router.post("/login",validate(adminLoginValidation),adminLogin);
router.get("/complaints",adminMiddleware,getAllComplaint);
router.put("/complaints/:id/status",adminMiddleware,updateComplaintStatus);
router.get("/dashboard",adminMiddleware,getComplaintStatus);
router.post("/logout",adminLogout);

module.exports=router;