const express=require("express");
const router=express.Router();

const authMiddleware=require("../middlewares/authMiddleware");
const { complaintValidation }=require("../validation/complaintValidation");
const { createComplaint,getMyComplaint,getComplaintById,updatedComplaint, deleteComplaint }=
require("../controllers/complaintController");

router.post("/create",authMiddleware,complaintValidation,createComplaint);
router.get("/my_complaint",authMiddleware,getMyComplaint);
router.get("/:id",authMiddleware,getComplaintById);
router.put("/:id",authMiddleware,complaintValidation,updatedComplaint);
router.delete("/:id",authMiddleware,deleteComplaint);

module.exports=router;

