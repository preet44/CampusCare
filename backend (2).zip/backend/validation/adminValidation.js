// const adminLoginValidation=(req,res)=>{
//     const {email,password}=req.body;
//     if(!email || !password){
//         return res.status(400).json({
//             success:false,
//             message:"Email and password are required"
//         });
//     }
//     next();

// }

const joi=require("joi");
const validateSignup=joi.object({
    email:joi.string().trim().lowercase().min(15).max(40).required(),
    password:joi.min(6).max(30).required()
});

module.exports={
    adminLoginValidation,
}