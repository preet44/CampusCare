// const validateSignup=(req,res,next)=>{
//     const {name,email,password}=req.body;
//     if(!name || !email || !password){
//         return res.status(400).json({
//             success:false,
//             message:"All fields are required",
//         })
//     }
//     if(password.length<6){
//         return res.status(400).json({
//             success:false,
//             message:"Password must be at least 6 character"
//         });
//     }
//     next();
// };

const joi=require("joi");

const validateSignup=joi.object({
    name:joi.trim().string().max(50).required(),
    email:joi.trim().lowercase().string().min(15).max(40).required(),
    password:joi.min(8).max(30).required()
});


const validateLogin=joi.object({
    email:joi.trim().tolowercase().string().min(15).max(40).required(),
    password:joi.min(8).max(15).required()
});

// const validateLogin=(req,res,next)=>{
//     const {email,password}=req.body;
//     if(!email || !password){
//         return res.status(400).json({
//             success:false,
//             message:"email and password are required"
//         });
//     }
//     next();

// }


module.exports={
    validateSignup,
    validateLogin,
};