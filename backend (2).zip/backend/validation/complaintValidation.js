// const complaintValidation=(req,res,next)=>{
//     const {title,description,category}=req.body;

//     if(!title || !description || !category){
//         return res.status(400).json({
//             success:false,
//             message:"All fields are required",
//         })
//     }
//     next();
// }
// module.exports=complaintValidation;

const joi=require("joi");
const { updatedComplaint } = require("../controllers/complaintController");

const complaintValidation=joi.object({
    title:joi.trim().string().min(5).max(100).required(),
    description:joi.trim().string().min(10).max(1000).required(),
    category:joi.trim().string().valid(
        "Academic","Hostel","Technical",
        "Canteen","Library","Furniture","Other")
        .required()
});

const updatedComplaint=joi.object({
    title:joi.trim().string().min(5).max(100),
    description:joi.trim().string().min(10).max(1000),
    category:joi.trim().string().valid(
         "Academic","Hostel","Technical",
        "Canteen","Library","Furniture","Other")
});

module.exports={
    complaintValidation,
    updatedComplaint,
};